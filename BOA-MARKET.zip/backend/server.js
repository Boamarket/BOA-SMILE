const express = require('express');
const cors = require('cors');
const admin = require('firebase-admin');
const mongoose = require('mongoose');
const stripe = require('stripe')('sk_test_your_stripe_key_here');

const app = express();
app.use(cors());
app.use(express.json());

// Firebase Admin SDK
admin.initializeApp({
  credential: admin.credential.applicationDefault(),
});

// MongoDB connection
mongoose.connect('mongodb://localhost:27017/boa-market', { useNewUrlParser: true, useUnifiedTopology: true });

// Product schema
const productSchema = new mongoose.Schema({
  name: String,
  price: Number,
  description: String,
  imageUrl: String,
});
const Product = mongoose.model('Product', productSchema);

// Routes
app.post('/signup', async (req, res) => {
  const { email, password } = req.body;
  try {
    const userRecord = await admin.auth().createUser({ email, password });
    res.status(201).json({ message: 'User created', userRecord });
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

app.get('/products', async (req, res) => {
  const products = await Product.find();
  res.json(products);
});

app.post('/payment', async (req, res) => {
  const { amount, token } = req.body;
  try {
    const charge = await stripe.charges.create({
      amount,
      currency: 'usd',
      source: token,
      description: 'BOA Market Purchase',
    });
    res.json({ message: 'Payment successful', charge });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

app.listen(5000, () => console.log('Server running on port 5000'));