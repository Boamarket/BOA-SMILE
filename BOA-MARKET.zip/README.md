# BOA Market

This is a basic version of the BOA Market app including:

- Backend: Node.js + Express + MongoDB + Firebase Admin + Stripe
- Frontend Web: React with product listings
- Firebase for authentication

## How to Run

### Backend Setup

1. `cd backend`
2. Run `npm install express mongoose firebase-admin stripe cors`
3. Run `node server.js`

### Frontend Web Setup

1. `cd boa-market-web`
2. Run `npm install axios react react-dom`
3. Run `npm start`

Make sure your backend is running on port 5000.